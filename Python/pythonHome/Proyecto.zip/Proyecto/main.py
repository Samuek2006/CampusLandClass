import modules.menus as menus
import util.login as login

def main():
    menus.menuCoordinador()
    login.register()

if __name__ == "__main__":
    main()