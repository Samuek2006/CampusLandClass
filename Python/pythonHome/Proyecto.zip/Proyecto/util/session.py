session = {
    "is_logged_in": False,
    "user": None,
    "rol": None
}